# CSS-Only Floating Labels

A Pen created on CodePen.io. Original URL: [https://codepen.io/kvncnls/pen/MWmJaPw](https://codepen.io/kvncnls/pen/MWmJaPw).

